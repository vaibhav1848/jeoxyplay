## License
### Strictly follow these rules, Or don't use the bot
&nbsp;

- Allowed only for fair use, Don't use for illegal purposes
- You are not allowed to remove the credits
- You can not edit credits and claim that you made it
- You are not allowed to make a youtube video with this source code
- If found anything violated, They will be reported to respective administration team