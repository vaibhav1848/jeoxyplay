### Bot Made By Joexy ###
  Note : Dont Delete Credits
 Put Bot Token And Prefix In .env
 
 ### Enjoy! ###