module.exports = (client) => {
  console.log("[Discord API]: Logged In As " + client.user.tag);
};
